'''
Name: Tirrell Rose

Description: This file creates the Tuition class

Date: 10/28/22
'''
class Tuition:
    #define class variables
    def __init__(self, state, entries):
        self.state = state
        self.entries = entries

    #calculates the average of all values in entries
    def avg(self):
        total = 0
        for entry in self.entries:
            total += entry
        return total/len(self.entries)

    #calculates the average rises of all values in entries
    def avgRise(self):
        rise = 0
        for i in range(len(self.entries)-1):
            rise += self.entries[i+1] - self.entries[i]
        return rise/(len(self.entries)-1)

    #uses the last rise and the overall average rises to predict the next tuition
    def predictOne(self):
        lastRise = self.entries[len(self.entries)-1] - self.entries[len(self.entries)-2]
        return self.entries[len(self.entries)-1] + (self.avgRise() + lastRise)/2

    #uses the last rise, average of last two rises, and the overall average rises to predict the two-year out tuition    
    def predictTwo(self):
        lastRise = self.entries[len(self.entries)-1] - self.entries[len(self.entries)-2]
        secondLastRise = self.entries[len(self.entries)-2] - self.entries[len(self.entries)-3]
        avgLastTwo = (lastRise + secondLastRise)/2
        return self.entries[len(self.entries)-1] + (self.avgRise() + lastRise + avgLastTwo)/3

