'''
Name: Tirrell Rose

Description: This file processes the csv file

Date: 10/28/22
'''
import tuition

#read in data from csv file and process
stateTuitionData = {}
with open("us_avg_tuition_1.csv") as tuitionFile:
    i = 0
    for line in tuitionFile:
        #print(line)
        row = line.split(",\"")
        #ignore first line in csv
        if i != 0:
            state = row[0]
            entriesData = []
            for x in range(len(row)-1):
                #process data by removing non-integer symbols
                s = row[x+1].replace("$","")
                s2 = s.replace(",","")
                s3 = s2.replace(" \"","")
                convertToInt = int(s3)
                entriesData.append(convertToInt) 
            #store each row as a Tuition object
            stateTuition = tuition.Tuition(state, entriesData)
            stateTuitionData[state] = stateTuition
            #print(stateTuition.avg())
        i += 1

#Query loop  
flag = True 
while(flag):
    #Give user options for input
    print("Enter 1 For Whole US Data")
    print("Enter 2 For Specific State Data")
    print("Enter 3 To Exit")
    #Obtain user's input
    query = str(input())
    #Case 1: Query for Whole US Data
    if query == "1":
        #Loop through all possible states
        totalAvg = 0
        totalAvgRise = 0
        totalPredictOne = 0
        totalPredictTwo = 0
        for state in stateTuitionData:
            #Print key statistics which are stored in the stateData dictionary
            s = stateTuitionData[state]
            totalAvg += s.avg()
            totalAvgRise += s.avgRise()
            totalPredictOne += s.predictOne()
            totalPredictTwo += s.predictTwo()
        totalAvg /= 50
        totalAvgRise /= 50
        totalPredictOne /= 50
        totalPredictTwo /= 50
        print("Average US Tuition: " + str(totalAvg))
        print("Average US Tuition Rise: " + str(totalAvgRise))
        print("Prediction For US Tuition in One Year: " + str(totalPredictOne))
        print("Prediction For US Tuition in Two Years: " + str(totalPredictTwo))
    #Case 2: Specific State Query
    elif query == "2":
        #Ask user for state input
        print("Enter State Name With Leading Capital (ie Arkansas)")
        inp = str(input())
        while( inp not in stateTuitionData):
            print("Invalid State Abbreviation! Enter Again:")
            inp = str(input())
        #Print key statistics for state inputed in query
        print("Average Tuition: " + str(stateTuitionData[inp].avg()))
        print("Average Tuition Rise: " + str(stateTuitionData[inp].avgRise()))
        print("One Year Tuition Prediction: " + str(stateTuitionData[inp].predictOne()))
        print("Two Year Tuition Prediction: " + str(stateTuitionData[inp].predictTwo()))
    #Case 3: Exit
    elif query == "3":
        #Set the flag to false so the while loops exits in the next loop
        flag = False
    #Case 4: Invalid Input
    else:
        print("Invalid Input!")